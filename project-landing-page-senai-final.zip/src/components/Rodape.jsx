import { Link } from 'react-router-dom';
import styles from '../css/Rodape.module.css';

function Rodape() {
  return (
    <footer className={styles.footer}>
      <div className={styles.socialBar}>
        <div className={styles.socialLinks}>
          <a href="https://facebook.com/senai" target="_blank" rel="noopener noreferrer">
            <i className="fab fa-facebook-f"></i>
          </a>
          <a href="https://twitter.com/senai" target="_blank" rel="noopener noreferrer">
            <i className="fab fa-twitter"></i>
          </a>
          <a href="https://youtube.com/senai" target="_blank" rel="noopener noreferrer">
            <i className="fab fa-youtube"></i>
          </a>
          <a href="https://linkedin.com/company/senai" target="_blank" rel="noopener noreferrer">
            <i className="fab fa-linkedin-in"></i>
          </a>
          <a href="https://instagram.com/senai" target="_blank" rel="noopener noreferrer">
            <i className="fab fa-instagram"></i>
          </a>
          <a href="tel:2733345201" className={styles.phone}>
            <i className="fas fa-phone"></i>
          </a>
        </div>
      </div>

      <div className={styles.mainContent}>
        <div className={styles.logoSection}>
          <img src="https://senaies.com.br/wp-content/uploads/2024/11/logo_senai.svg" alt="SENAI Logo" className={styles.logo} />
          <h3>SENAI ESPÍRITO SANTO</h3>
          <p>
            <i className="fas fa-map-marker-alt"></i>
            Av. Marechal Mascarenhas de Moraes, 2075, Bento Ferreira, Vitória - ES, 29050-625
          </p>
        </div>

        <div className={styles.contactSection}>
          <h3>CENTRAL DE RELACIONAMENTO</h3>
          <p>
            <i className="fas fa-phone"></i>
            (27) 3334-5201
          </p>
          <p>
            <i className="fas fa-envelope"></i>
            senai@senaies.com.br
          </p>
        </div>
      </div>

      <nav className={styles.footerNav}>
        <Link to="/unidades">Unidades</Link>
        <Link to="/o-senai">O SENAI</Link>
        <Link to="/perguntas-frequentes">Perguntas Frequentes</Link>
        <Link to="/fale-conosco">Fale Conosco</Link>
        <Link to="/transparencia">Transparência</Link>
        <Link to="/para-sua-empresa">Para a sua empresa</Link>
        <Link to="/trabalhe-conosco">Trabalhe Conosco</Link>
        <Link to="/privacidade">Política de Privacidade</Link>
        <Link to="/termos">Termos de Uso</Link>
        <Link to="/denuncias">Canal de Denúncias</Link>
      </nav>

      <div className={styles.copyright}>
        <p>© 2025 SENAI ES - Departamento Regional do Espírito Santo. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
}

export default Rodape;