import { useState } from 'react';
import styles from '../css/Cadastro.module.css';

function Cadastro() {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    senha: '',
    confirmarSenha: ''
  });

  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};

    // Nome validation
    if (!formData.nome.trim()) {
      newErrors.nome = 'Nome é obrigatório';
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email || !emailRegex.test(formData.email)) {
      newErrors.email = 'Email inválido';
    }

    // Telefone validation
    const phoneRegex = /^\(\d{2}\) \d{5}-\d{4}$/;
    if (!formData.telefone || !phoneRegex.test(formData.telefone)) {
      newErrors.telefone = 'Telefone inválido. Use o formato (99) 99999-9999';
    }

    // Senha validation
    if (formData.senha.length < 8) {
      newErrors.senha = 'A senha deve ter no mínimo 8 caracteres';
    } else if (!/(?=.*[A-Z])/.test(formData.senha)) {
      newErrors.senha = 'A senha deve conter pelo menos uma letra maiúscula';
    } else if (!/(?=.*[0-9])/.test(formData.senha)) {
      newErrors.senha = 'A senha deve conter pelo menos um número';
    } else if (!/(?=.*[!@#$%^&*])/.test(formData.senha)) {
      newErrors.senha = 'A senha deve conter pelo menos um caractere especial';
    }

    // Confirmar Senha validation
    if (formData.senha !== formData.confirmarSenha) {
      newErrors.confirmarSenha = 'As senhas não coincidem';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      // Submit form
      console.log('Form submitted:', formData);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    let formattedValue = value;

    // Format phone number
    if (name === 'telefone') {
      formattedValue = value
        .replace(/\D/g, '')
        .replace(/^(\d{2})(\d)/g, '($1) $2')
        .replace(/(\d{5})(\d)/, '$1-$2')
        .slice(0, 15);
    }

    setFormData(prev => ({
      ...prev,
      [name]: formattedValue
    }));
  };

  return (
    <div className={styles.cadastroContainer}>
      <h2>Cadastro</h2>
      <form onSubmit={handleSubmit} className={styles.form}>
        <div className={styles.formGroup}>
          <label htmlFor="nome">Nome Completo</label>
          <input
            type="text"
            id="nome"
            name="nome"
            value={formData.nome}
            onChange={handleChange}
            className={errors.nome ? styles.error : ''}
          />
          {errors.nome && <span className={styles.errorMessage}>{errors.nome}</span>}
        </div>

        <div className={styles.formGroup}>
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className={errors.email ? styles.error : ''}
          />
          {errors.email && <span className={styles.errorMessage}>{errors.email}</span>}
        </div>

        <div className={styles.formGroup}>
          <label htmlFor="telefone">Telefone</label>
          <input
            type="text"
            id="telefone"
            name="telefone"
            value={formData.telefone}
            onChange={handleChange}
            placeholder="(99) 99999-9999"
            className={errors.telefone ? styles.error : ''}
          />
          {errors.telefone && <span className={styles.errorMessage}>{errors.telefone}</span>}
        </div>

        <div className={styles.formGroup}>
          <label htmlFor="senha">Senha</label>
          <input
            type="password"
            id="senha"
            name="senha"
            value={formData.senha}
            onChange={handleChange}
            className={errors.senha ? styles.error : ''}
          />
          {errors.senha && <span className={styles.errorMessage}>{errors.senha}</span>}
        </div>

        <div className={styles.formGroup}>
          <label htmlFor="confirmarSenha">Confirmar Senha</label>
          <input
            type="password"
            id="confirmarSenha"
            name="confirmarSenha"
            value={formData.confirmarSenha}
            onChange={handleChange}
            className={errors.confirmarSenha ? styles.error : ''}
          />
          {errors.confirmarSenha && <span className={styles.errorMessage}>{errors.confirmarSenha}</span>}
        </div>

        <button type="submit" className={styles.submitButton}>
          Cadastrar
        </button>
      </form>
    </div>
  );
}

export default Cadastro;