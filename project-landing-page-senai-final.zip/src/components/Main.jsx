import styles from '../css/Main.module.css';

function Main() {
  return (
    <main className={styles.mainContainer}>
      <section className={styles.hero}>
        <h1>Bem-vindo ao SENAI</h1>
        <p>Transformando vidas através da educação profissional</p>
      </section>
    </main>
  );
}

export default Main;