import { useNavigate } from 'react-router-dom';
import styles from '../css/Error.module.css';

function Error() {
  const navigate = useNavigate();

  return (
    <div className={styles.errorContainer}>
      <img 
        src="https://images.pexels.com/photos/4439425/pexels-photo-4439425.jpeg" 
        alt="Error" 
        className={styles.errorImage} 
      />
      <h2>Oops! Algo deu errado...</h2>
      <p>A página que você está procurando não foi encontrada ou está temporariamente indisponível.</p>
      <button 
        onClick={() => navigate('/')}
        className={styles.homeButton}
      >
        Voltar para a Página Inicial
      </button>
    </div>
  );
}

export default Error;