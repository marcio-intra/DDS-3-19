import { useEffect } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import styles from '../css/Home.module.css';

function Home() {
  const news = [
    {
      id: 1,
      title: "Inovação na Indústria 4.0",
      description: "SENAI lidera transformação digital na indústria brasileira",
      image: "https://images.pexels.com/photos/3862634/pexels-photo-3862634.jpeg"
    },
    {
      id: 2,
      title: "Novos Cursos Tecnológicos",
      description: "Prepare-se para o futuro com nossos cursos atualizados",
      image: "https://images.pexels.com/photos/5473298/pexels-photo-5473298.jpeg"
    },
    {
      id: 3,
      title: "Parcerias Empresariais",
      description: "SENAI amplia network com grandes empresas do setor industrial",
      image: "https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg"
    }
  ];

  return (
    <div className={styles.homeContainer}>
      <Swiper
        modules={[Navigation, Pagination, Autoplay]}
        navigation
        pagination={{ clickable: true }}
        autoplay={{ delay: 5000 }}
        className={styles.swiper}
      >
        {news.map((item) => (
          <SwiperSlide key={item.id} className={styles.slide}>
            <img src={item.image} alt={item.title} />
            <div className={styles.slideContent}>
              <h2>{item.title}</h2>
              <p>{item.description}</p>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}

export default Home;