import { useNavigate } from 'react-router-dom';
import styles from '../css/Config.module.css';

function Config() {
  const navigate = useNavigate();

  const configOptions = [
    {
      title: 'Preferências do Sistema',
      description: 'Personalize a aparência e comportamento do sistema',
      icon: '🎨'
    },
    {
      title: 'Notificações',
      description: 'Configure suas preferências de notificação',
      icon: '🔔'
    },
    {
      title: 'Segurança',
      description: 'Gerencie suas configurações de segurança',
      icon: '🔒'
    }
  ];

  const handleOptionClick = () => {
    navigate('/error');
  };

  return (
    <div className={styles.configContainer}>
      <h2>Configurações</h2>
      <div className={styles.optionsGrid}>
        {configOptions.map((option, index) => (
          <div 
            key={index}
            className={styles.optionCard}
            onClick={handleOptionClick}
          >
            <span className={styles.icon}>{option.icon}</span>
            <h3>{option.title}</h3>
            <p>{option.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Config;