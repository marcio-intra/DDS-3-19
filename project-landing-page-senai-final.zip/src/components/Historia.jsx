import styles from '../css/Historia.module.css';

function Historia() {
  return (
    <div className={styles.historiaContainer}>
      <h2>Nossa História</h2>
      <div className={styles.content}>
        <div className={styles.text}>
          <p>O SENAI foi criado em 22 de janeiro de 1942, pelo decreto-lei 4.048 do então presidente Getúlio Vargas, com a missão de formar profissionais para a incipiente indústria nacional.</p>
          <p>Ao longo de mais de 80 anos, o SENAI se consolidou como o maior complexo de educação profissional da América Latina, qualificando mais de 73 milhões de trabalhadores brasileiros.</p>
          <p>Hoje, o SENAI é referência em educação profissional, oferecendo cursos técnicos, de qualificação, aprendizagem industrial e pós-graduação, além de serviços tecnológicos e inovação para a indústria.</p>
        </div>
        <div className={styles.video}>
          <iframe 
            width="560" 
            height="315" 
            src="https://www.youtube.com/embed/3y8T2KKAMws?si=1ZCpcXNJjCyDQFk8" 
            title="YouTube video player" 
            frameborder="0" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
            referrerpolicy="strict-origin-when-cross-origin" 
            allowfullscreen>
          </iframe>
        </div>
        <div className={styles.timeline}>
          <div className={styles.timelineItem}>
            <h3>1942</h3>
            <p>Fundação do SENAI</p>
          </div>
          <div className={styles.timelineItem}>
            <h3>1960</h3>
            <p>Expansão nacional</p>
          </div>
          <div className={styles.timelineItem}>
            <h3>2000</h3>
            <p>Modernização tecnológica</p>
          </div>
          <div className={styles.timelineItem}>
            <h3>Hoje</h3>
            <p>Referência em inovação</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Historia;