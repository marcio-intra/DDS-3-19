import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from '../css/Cursos.module.css';

function Cursos() {
  const navigate = useNavigate();
  const [selectedCourse, setSelectedCourse] = useState(null);

  const cursos = [
    {
      id: 1,
      titulo: 'Técnico em Automação Industrial',
      descricao: 'Desenvolva habilidades em sistemas automatizados e controle industrial.',
      imagem: 'https://images.pexels.com/photos/3912981/pexels-photo-3912981.jpeg'
    },
    {
      id: 2,
      titulo: 'Técnico em Desenvolvimento de Sistemas',
      descricao: 'Aprenda a criar aplicações e sistemas computacionais modernos.',
      imagem: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg'
    },
    {
      id: 3,
      titulo: 'Técnico em Mecatrônica',
      descricao: 'Combine mecânica, eletrônica e computação em sistemas integrados.',
      imagem: 'https://images.pexels.com/photos/3862130/pexels-photo-3862130.jpeg'
    }
  ];

  const handleCourseClick = (curso) => {
    setSelectedCourse(curso);
  };

  const handleSaibaMais = () => {
    navigate('/login');
  };

  return (
    <div className={styles.cursosContainer}>
      {!selectedCourse ? (
        <>
          <h2>Nossos Cursos</h2>
          <div className={styles.cursosGrid}>
            {cursos.map((curso) => (
              <div 
                key={curso.id} 
                className={styles.cursoCard}
                onClick={() => handleCourseClick(curso)}
              >
                <img src={curso.imagem} alt={curso.titulo} />
                <h3>{curso.titulo}</h3>
                <p>{curso.descricao}</p>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className={styles.cursoDetalhes}>
          <button 
            className={styles.voltar}
            onClick={() => setSelectedCourse(null)}
          >
            Voltar
          </button>
          <h2>{selectedCourse.titulo}</h2>
          <img src={selectedCourse.imagem} alt={selectedCourse.titulo} />
          <p>{selectedCourse.descricao}</p>
          <button 
            className={styles.saibaMais}
            onClick={handleSaibaMais}
          >
            Saiba Mais
          </button>
        </div>
      )}
    </div>
  );
}

export default Cursos;