import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Rodape from './components/Rodape';
import Cursos from './components/Cursos';
import Historia from './components/Historia';
import Cadastro from './components/Cadastro';
import Login from './components/Login';
import Error from './components/Error';
import Config from './components/Config';

function App() {
  return (
    <Router>
      <div className="app">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cursos" element={<Cursos />} />
          <Route path="/historia" element={<Historia />} />
          <Route path="/cadastro" element={<Cadastro />} />
          <Route path="/login" element={<Login />} />
          <Route path="/config" element={<Config />} />
          <Route path="/error" element={<Error />} />
          <Route path="*" element={<Error />} />
        </Routes>
        <Rodape />
      </div>
    </Router>
  );
}

export default App;